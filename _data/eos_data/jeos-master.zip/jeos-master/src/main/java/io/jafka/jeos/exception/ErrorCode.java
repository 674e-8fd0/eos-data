package io.jafka.jeos.exception;

public interface ErrorCode {
    int getNumber();
}
