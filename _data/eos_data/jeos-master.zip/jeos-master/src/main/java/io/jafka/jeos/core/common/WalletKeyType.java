package io.jafka.jeos.core.common;

public enum WalletKeyType {
    K1, R1
}
