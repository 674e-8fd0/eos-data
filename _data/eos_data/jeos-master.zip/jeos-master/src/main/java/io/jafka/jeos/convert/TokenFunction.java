package io.jafka.jeos.convert;

/**
 * 
 * @author adyliu (imxylz@gmail.com)
 * @since 2018年9月6日
 */
public enum TokenFunction {

    transfer, //
    account, //
    ram, //
    delegate, //
    voteproducer//
    ;
}
